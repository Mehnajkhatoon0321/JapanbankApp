package com.example.finalfigma

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
