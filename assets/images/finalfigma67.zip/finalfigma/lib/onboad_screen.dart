import 'dart:async';

import 'package:finalfigma/Choose_user.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';



class OnbordScreen extends StatefulWidget {
  @override
  _OnbordScreenState createState() => _OnbordScreenState();
}

class _OnbordScreenState extends State<OnbordScreen> {
  int state = 1;
  // List<SliderModel> slides =  [];

  List<SliderModel> slides = [
    SliderModel(
        title: 'Convenient',
        description: 'Open Bank Account, Check Balance, Transfer Funds, Apply for Debit and Credit Cards.',
        image: 'assets/images/Frame.png',
        check: true,
        description2: ''),
    SliderModel(
        title: 'Scan & Pay',
        description: 'Use MARUHAN App When you Shop, Dine and Make QR Payment, It\'s Easy, Fast and Secure.',
        image: 'assets/images/Frame1.png',
        check: false,
        description2: ''),
    SliderModel(
        title: 'Do More',
        description: 'Perform Mobile Top Up, Pay Bills, Withdraw Cash without Card with Cash by Code.',
        image: 'assets/images/Frame2.png',
        check: false,
        description2: ''),
  ];


  int currentIndex = 0;
  late PageController _controller;

  int _currentPage = 0;
  late Timer _timer;
  PageController _pageController = PageController(
    initialPage: 0,
  );

  @override
  void initState() {
    super.initState();
    // _timer = Timer.periodic(const Duration(seconds: 3), (Timer timer) {
    //   if (_currentPage < 3) {
    //     _currentPage++;
    //   } else {
    //     _currentPage = 0;
    //   }
    //
    //   _pageController.animateToPage(
    //     _currentPage,
    //     duration: const Duration(milliseconds: 350),
    //     curve: Curves.easeIn,
    //   );
    // });
  }

  @override
  void dispose() {
    super.dispose();
    // _timer.cancel();
  }

  @override
  Widget build(BuildContext context) {
    final double height = MediaQuery.of(context).size.height * 0.9;
    final double width = MediaQuery.of(context).size.width;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: MediaQuery(
          data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
          child: Stack(
            children: <Widget>[

              Container(
                width: double.infinity,
                height: double.infinity,
                // color: Colors.grey,
                // height: height,
                child: PageView.builder(
                    scrollDirection: Axis.horizontal,
                    controller: _pageController,
                    onPageChanged: (value) {
                      setState(() {
                        currentIndex = value;
                      });
                    },
                    itemCount: slides.length,
                    itemBuilder: (context, index) {
                      // contents of slider
                      return Stack(children: <Widget>[
                        Column(
                          children: [

                            SizedBox(height: height/8,),
                            SizedBox(
                              width: width/1.5,
                              height: height/3,
                              child: Slider(
                                image: slides[index].getImage(),
                              ),
                            ),
                            SizedBox(height: height/10,),
                            Padding(
                              padding: EdgeInsets.fromLTRB(
                                  width / 15, 10, width / 15, 0),
                              child: Container(
                                // color: Colors.purpleAccent,
                                height: 260,

                                alignment: Alignment.center,
                                child: Column(

                                  children: [
                                    Text(
                                        slides[index].getTitle(),
                                        textScaleFactor: 1.0,
                                        style: const TextStyle(
                                          fontSize: 35,
                                          color: Colors.black,
                                          fontFamily: 'inter',
                                          fontWeight:FontWeight.w600,
                                        ),
                                        textAlign: TextAlign.center),
                                    SizedBox(height: height/30,),
                                    Text(
                                        slides[index].description,
                                        textScaleFactor: 1.0,
                                        style: const TextStyle(
                                            fontSize: 16,
                                            color: Color(0xff5A5A5A),
                                            fontFamily: 'inter'),
                                        textAlign: TextAlign.center),
                                  ],
                                ),
                              ),
                            ),

                          ],
                        ),



                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Padding(
                            padding: const EdgeInsets.only(right: 0, top: 0,bottom: 25),
                            child: InkWell(
                              onTap: () {
                                Navigator.pushAndRemoveUntil(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Choose_user()),
                                    // builder: (context) => Language()),
                                        (Route<dynamic> route) => false);
                              },
                              child: Container(
                                height: 30,
                                width: 70,
                                alignment: Alignment.center,

                                child:  currentIndex==2
                                    ? const Text(
                                  'Done',
                                  textScaleFactor: 1.0,
                                  style: TextStyle(
                                      fontSize: 18, color: Colors.grey),
                                )
                                    :const Text(
                                  'Skip',
                                  textScaleFactor: 1.0,
                                  style: TextStyle(
                                      fontSize: 18, color: Colors.grey),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ]);
                    }),
              ),
              currentIndex==0
                  ?const SizedBox()
                  :Positioned(
                  left: 0,
                  bottom: 20,
                  child: Container(
                    // height: width >380?height*0.180:height*0.200,
                    // width: width >380?width*0.08:width*0.10,
                    height:height*0.230,
                    width:width*0.12,
                    alignment: Alignment.center,
                    child:  InkWell(
                        onTap: (){
                          _pageController.previousPage(duration: const Duration(milliseconds: 10), curve: Curves.easeIn);
                        },
                        child:Stack(
                          children: [
                            Center(child: Image.asset('assets/images/slidepic2.png',width: 50,)),
                            Center(child: Image.asset('assets/images/arrowright.png',width: 40,))
                          ],
                        )

                    ),
                  )),
              Positioned(
                  right: 0,
                  bottom: 20,
                  child: Container(
                    // color: Colors.cyan,
                    // height: width >375?height*0.180:height*0.200,
                    // width: width >375?width*0.08:width*0.11,
                    height:height*0.230,
                    width:width*0.12,
                    alignment: Alignment.center,
                    child: InkWell(
                        onTap: (){
                          _pageController.nextPage(duration: const Duration(milliseconds: 10), curve: Curves.easeIn);
                        },
                        child: Stack(
                          children: [
                            Center(child: Image.asset('assets/images/slidepic1.png',width: 50,)),
                            Center(child: Image.asset('assets/images/threearrowleft.png',width: 40,))
                          ],
                        )
                    ),
                  )),
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  // color: Colors.grey,
                  margin: EdgeInsets.fromLTRB(5, 0, 0, height/4),
                  alignment: Alignment.bottomCenter,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      slides.length,
                          (index) => buildDot(index, context),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),

        // backgroundColor: Colors.white,
      ),
    );
  }

// container created for dots
  Container buildDot(int index, BuildContext context) {
    return Container(
      height: 10,
      width: currentIndex == index ? 10 : 10,
      margin: EdgeInsets.only(right: 4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: currentIndex == index
            ? Colors.red
            : Colors.grey,
      ),
    );
  }
}

// ignore: must_be_immutable
// slider declared
class Slider extends StatelessWidget {
  String image;

  Slider({required this.image});

  int get state => 1;

  @override
  Widget build(BuildContext context) {
    final double height = MediaQuery.of(context).size.height * 0.5;
    return SizedBox(
      width:  300,
      // height:  ,
      child: Image.asset(
        image,
        fit: BoxFit.fill,
      ),
    );
  }
}

class SliderModel {
  String image;
  String title;
  String description;
  String description2;
  bool check;
  // int hight;

// Constructor for variables
  SliderModel({
    required this.title,
    required this.description,
    required this.description2,
    required this.image,
    required this.check,
  });

  void setImage(String getImage) {
    image = getImage;
  }

  void setCheck(bool getCheck) {
    check = getCheck;
  }

  void setTitle(String getTitle) {
    title = getTitle;
  }

  void setDescription(String getDescription) {
    description = getDescription;
  }

  void setDescription2(String getDescription2) {
    description2 = getDescription2;
  }

  bool getCheck() {
    return check;
  }

  String getImage() {
    return image;
  }

  String getTitle() {
    return title;
  }

  String getDescription() {
    return description;
  }

  String getDescription2() {
    return description2;
  }
}



// List created

class BezierClipper extends CustomClipper<Path> {
  final int state;
  BezierClipper(this.state);

  Path _getInitialClip(Size size) {
    Path path = Path();
    final double _xScaling = size.width / 414;
    final double _yScaling = size.height / 363.15;
    path.lineTo(
        -0.003999999999997783 * _xScaling, 321.78499999999997 * _yScaling);
    path.cubicTo(
      -0.003999999999997783 * _xScaling,
      311.78499999999997 * _yScaling,
      23.461000000000002 * _xScaling,
      363.15099999999995 * _yScaling,
      61.553 * _xScaling,
      363.15099999999995 * _yScaling,
    );
    path.cubicTo(
      119.645 * _xScaling,
      363.15099999999995 * _yScaling,
      142.21699999999998 * _xScaling,
      300.186 * _yScaling,
      203.29500000000002 * _xScaling,
      307.21 * _yScaling,
    );
    path.cubicTo(
      264.373 * _xScaling,
      314.234 * _yScaling,
      282.666 * _xScaling,
      333.47299999999996 * _yScaling,
      338.408 * _xScaling,
      333.47299999999996 * _yScaling,
    );
    path.cubicTo(
      394.15000000000003 * _xScaling,
      333.47299999999996 * _yScaling,
      413.99600000000004 * _xScaling,
      254.199 * _yScaling,
      413.99600000000004 * _xScaling,
      254.199 * _yScaling,
    );
    path.cubicTo(
      413.99600000000004 * _xScaling,
      254.199 * _yScaling,
      413.99600000000004 * _xScaling,
      0 * _yScaling,
      413.99600000000004 * _xScaling,
      0 * _yScaling,
    );
    path.cubicTo(
      413.99600000000004 * _xScaling,
      0 * _yScaling,
      -0.003999999999976467 * _xScaling,
      0 * _yScaling,
      -0.003999999999976467 * _xScaling,
      0 * _yScaling,
    );
    path.cubicTo(
      -0.003999999999976467 * _xScaling,
      0 * _yScaling,
      -0.003999999999997783 * _xScaling,
      341.78499999999997 * _yScaling,
      -0.003999999999997783 * _xScaling,
      341.78499999999997 * _yScaling,
    );
    return path;
  }

  Path _getFinalClip(Size size) {
    Path path = Path();
    final double _xScaling = size.width / 414;
    final double _yScaling = size.height / 01.69;
    path.lineTo(-0.003999999999997783 * _xScaling, 217.841 * _yScaling);
    path.cubicTo(
      -0.003999999999997783 * _xScaling,
      217.841 * _yScaling,
      19.14 * _xScaling,
      265.91999999999996 * _yScaling,
      67.233 * _xScaling,
      265.91999999999996 * _yScaling,
    );
    path.cubicTo(
      115.326 * _xScaling,
      265.91999999999996 * _yScaling,
      112.752 * _xScaling,
      234.611 * _yScaling,
      173.83299999999997 * _xScaling,
      241.635 * _yScaling,
    );
    path.cubicTo(
      234.914 * _xScaling,
      248.659 * _yScaling,
      272.866 * _xScaling,
      301.691 * _yScaling,
      328.608 * _xScaling,
      301.691 * _yScaling,
    );
    path.cubicTo(
      384.34999999999997 * _xScaling,
      301.691 * _yScaling,
      413.99600000000004 * _xScaling,
      201.977 * _yScaling,
      413.99600000000004 * _xScaling,
      201.977 * _yScaling,
    );
    path.cubicTo(
      413.99600000000004 * _xScaling,
      201.977 * _yScaling,
      413.99600000000004 * _xScaling,
      0 * _yScaling,
      413.99600000000004 * _xScaling,
      0 * _yScaling,
    );
    path.cubicTo(
      413.99600000000004 * _xScaling,
      0 * _yScaling,
      -0.003999999999976467 * _xScaling,
      0 * _yScaling,
      -0.003999999999976467 * _xScaling,
      0 * _yScaling,
    );
    path.cubicTo(
      -0.003999999999976467 * _xScaling,
      0 * _yScaling,
      -0.003999999999997783 * _xScaling,
      217.841 * _yScaling,
      -0.003999999999997783 * _xScaling,
      217.841 * _yScaling,
    );
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => true;

  @override
  Path getClip(Size size) =>
      state == 1 ? _getInitialClip(size) : _getFinalClip(size);
}
