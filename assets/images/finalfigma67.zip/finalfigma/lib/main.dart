import 'package:finalfigma/onboad_screen.dart';
import 'package:finalfigma/splash_screen.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    initialRoute: 'splash_screen',
    routes: {'splash_screen':(context)=>splash_screen(),

      'OnbordScreen':(context)=>OnbordScreen(),


    },
  ));
}

