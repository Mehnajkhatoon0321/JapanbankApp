import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
class language extends StatefulWidget {
  const language({Key? key}) : super(key: key);

  @override
  State<language> createState() => _languageState();
}

class _languageState extends State<language> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
